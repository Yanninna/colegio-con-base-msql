
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesor`
--

CREATE TABLE `profesor` (
  `id` int(11) NOT NULL,
  `apellido` varchar(100) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `materia` varchar(150) NOT NULL,
  `turno` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `profesor`
--

INSERT INTO `profesor` (`id`, `apellido`, `nombre`, `materia`, `turno`) VALUES
(1, 'gallo', 'rafael', 'matematicas', 'tarde'),
(2, 'perez', 'adrian', 'arquitectura ', 'nocturno'),
(3, 'sanchez', 'roberto', 'edi', 'mañana'),
(4, 'soria', 'sofia', 'inges tec.', 'nocturno');
