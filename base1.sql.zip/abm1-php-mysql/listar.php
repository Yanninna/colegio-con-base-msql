<html>
<head>
<title>LISTAR</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
  <h6>

<?php
$conexion=mysqli_connect("localhost","root","","base1") or
    die("Problemas con la conexión");

$registros=mysqli_query($conexion,"select alumno.id as id, alumno.nombre as nombre, alumno.apellido as apellido, alumno.mail as mail, carrera.nombre as carrera from alumno join carrera on carrera.id=alumno.idCarrera;") 
                  or die("Problemas en el select:".mysqli_error($conexion));

while ($reg=mysqli_fetch_array($registros))
{
  echo "id:".$reg['id']."<br>";
  echo "Nombre:".$reg['nombre']."<br>";
  echo "Apellido:".$reg['apellido']."<br>";
  echo "Mail:".$reg['mail']."<br>";
  echo "idCarrera:";
 
  }

mysqli_close($conexion);

  echo "<br>";
  echo "<hr>";
?>
<form action="index.html" method="post">
Volver a menu Principal:
<input type="submit" value="Menu Principalncipal">

	</form>

</h6>
</body>
</html>