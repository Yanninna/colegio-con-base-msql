<html>
 <head>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet"/>

  <title>Alta PHP</title>
  <link rel="stylesheet"  href="style.css">
 </head>
 <body>
 	
<?php
$conexion=mysqli_connect("localhost","root","","base1") or
    die("Problemas con la conexión");
$nombre = $_REQUEST['nombre'];
$apellido = $_REQUEST['apellido'];
$mail = $_REQUEST['mail'];
$carrera = $_REQUEST['idCarrera'];
mysqli_query($conexion,"insert into alumno(nombre,apellido,mail,idCarrera) values 
                       ('".$nombre."','".$apellido."','".$mail."',".$carrera.");")
  or die("Problemas en el select".mysqli_error($conexion));

mysqli_close($conexion);

echo "El alumno fue dado de alta. ";
?>
<form action="index.html" method="post">
Volver a menu Principal:
<input type="submit" value="Menu Principalncipal">
</form>


</body>
</html>

