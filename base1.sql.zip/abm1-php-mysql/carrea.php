<html>
<head>
<title>Problema</title>
</head>
<body>
<?php
$conexion=mysqli_connect("localhost","root","","base1") or
    die("Problemas con la conexión");
                                                                                                                                                                                                                                                                                              
$registros=mysqli_query($conexion,"select carrera.id as Id, 
carrera.nombre as nombre join carrera on carrera.id=carrera.id;") or
   die("Problemas en el select:".mysqli_error($conexion));

while ($reg=mysqli_fetch_array($registros))
{
  echo "ID:".$reg['id']."<br>";
  echo "Nombre:".$reg['nombre']."<br>";
 
  echo "<hr>";
}
mysqli_close($conexion);                              
?>
<form action="index.html" method="post">
Volver a menu Principal:
<input type="submit" value="Menu Principalncipal">
</form>
</body>
</html>