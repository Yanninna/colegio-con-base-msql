<html>
<head>
<title>Problema</title>
</head>
<body>
<?php
$conexion=mysqli_connect("localhost","root","","base1") or
    die("Problemas con la conexión");
                                                                                                                                                                                                                                                                                              
$registros=mysqli_query($conexion,"select alumno.id as Id, 
alumno.nombre as Nombre, alumno.mail as Mail, carrera.nombre as
 Carrera from alumno join carrera on carrera.nombre=carrera.nombre;") or
   die("Problemas en el select:".mysqli_error($conexion));

while ($reg=mysqli_fetch_array($registros))
{
  echo "ID:".$reg['Id']."<br>";
  echo "Nombre:".$reg['Nombre']."<br>";
  echo "Mail:".$reg['Mail']."<br>";
  echo "<hr>";
}
mysqli_close($conexion);                              
?>
<form action="index.html" method="post">
Volver a menu Principal:
<input type="submit" value="Menu Principalncipal">
</form>
</body>
</html>
                                                                                                   