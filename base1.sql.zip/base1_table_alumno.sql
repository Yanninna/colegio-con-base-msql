
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumno`
--

CREATE TABLE `alumno` (
  `id` int(5) NOT NULL,
  `nombre` varchar(20) DEFAULT NULL,
  `apellido` varchar(100) NOT NULL,
  `mail` varchar(30) DEFAULT NULL,
  `idCarrera` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `alumno`
--

INSERT INTO `alumno` (`id`, `nombre`, `apellido`, `mail`, `idCarrera`) VALUES
(1, 'luca asset', 'rigoni', 'luca@gmail.com', '2'),
(4, 'mariano', 'costas', 'mariano@gmail.com', '3'),
(5, 'dylan', '', 'dylan@gmail.com', '4');
